﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Fila : MonoBehaviour {

    //Criação o vetor para armazenar nomes
    public string[] nomes;
	//Variavel que guarda a posicao da fila
    public int posicao;
    //Adiciona o campo Input Field
    public InputField IFNomes;
    public Text caixaDeTexto;

	void Start () {
        //inicializa o vetor com 5 posições
        nomes = new string[5];
        posicao = 0;
	}
	
    //método que guarda os nomes
    public void salvaNomes()
    {
        if (posicao < 5)
        {
            nomes[posicao] = IFNomes.text;
            posicao = posicao + 1;
            IFNomes.text = string.Empty;
        }
        else
        {
            print("Fila cheia!");
        }
    }

    //método que exibe o conteúdo do vetor
    public void mostraNomes()
    {
        caixaDeTexto.text = string.Empty;

        for (int x = 0; x < posicao; x++)
        {
            caixaDeTexto.text += nomes[x] + "\n";
        }
    }

    //método que remove iten da fila
    public void removeNome()
    {

        if (posicao > 0)
        {
            string aux;
            for (int y = 0; y < posicao; y++)
            {
                if (y < (posicao - 1))
                {
                    aux = nomes[y + 1];
                    nomes[y] = aux;
                }
            }
            
            posicao = posicao - 1;
        }
        else
        {
            print("Fila vazia");
        }

    }




    void Update()
    {
		
	}
}
